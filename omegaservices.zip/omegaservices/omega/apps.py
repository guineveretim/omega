from django.apps import AppConfig


class OmegaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'omega'
